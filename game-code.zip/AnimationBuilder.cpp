#include "AnimationBuilder.h"
namespace AnimationBuilder {

    Animation* buildAnimation() {

        Animation* anim = new Animation();
        return anim;
    }
}