#include "BoneFrame.h"

BoneFrame::BoneFrame(std::vector<Matrix>* bones, std::vector<std::vector<int>>* indexes, std::vector<std::vector<float>>* weights) {
    _bones = bones;
    _indexes = indexes;
    _weights = weights;
}

BoneFrame::~BoneFrame() {
    delete _bones;
    delete _indexes;
    delete _weights;
}

std::vector<Matrix>* BoneFrame::getBones() {
    return _bones;
}

std::vector<std::vector<int>>* BoneFrame::getIndexes() {
    return _indexes;
}

std::vector<std::vector<float>>* BoneFrame::getWeights() {
    return _weights;
}
