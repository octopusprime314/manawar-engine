#include "BonedModel.h"
#include "BonedShader.h"

BonedModel::BonedModel(std::string name, ViewManagerEvents* eventWrapper) :
    AnimatedModel(name, eventWrapper) {

    //Override default shader with a bone animation shader
    _shaderProgram = new BonedShader();
    _shaderProgram->build("shaders/boneShader");

    BoneFrame *frame = getAnimation()->getBoneFrames()[0];

    auto frameIndexes = frame->getIndexes();
    auto frameWeights = frame->getWeights();

    //Now flatten bone indexes and weights out for opengl
    size_t boneIndexesBuffSize = frameIndexes->size() * 4;
    float* flattenIndexes = new float[boneIndexesBuffSize]; 
    float* flattenWeights = new float[boneIndexesBuffSize]; 
    
    int i = 0; //iterates through vertices indexes
    for (auto indexes : *frameIndexes) {
        flattenIndexes[i++] = indexes[0];
        flattenIndexes[i++] = indexes[1];
        flattenIndexes[i++] = indexes[2];
        flattenIndexes[i++] = indexes[3];
    }
    i = 0; //Reset for normal indexes
    for (auto weights : *frameWeights) {
        flattenWeights[i++] = weights[0];
        flattenWeights[i++] = weights[1];
        flattenWeights[i++] = weights[2];
        flattenWeights[i++] = weights[3];
    }

    glGenBuffers(1, &_indexContext);
    glBindBuffer(GL_ARRAY_BUFFER, _indexContext); //Load in vertex buffer context
    //Load the vertex data into the current vertex context
    glBufferData(GL_ARRAY_BUFFER, sizeof(float)*boneIndexesBuffSize, flattenIndexes, GL_STATIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, 0); //Unbind

    glGenBuffers(1, &_weightContext);
    glBindBuffer(GL_ARRAY_BUFFER, _weightContext); //Load in normal buffer context
    //Load the normal data into the current normal context
    glBufferData(GL_ARRAY_BUFFER, sizeof(float)*boneIndexesBuffSize, flattenWeights, GL_STATIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, 0); //Unbind

    _doubleBufferIndex = false;

    delete[] flattenIndexes;
    delete[] flattenWeights;
}

BonedModel::~BonedModel() {

    for (auto animation : _animations) {
        delete animation;
    }
}

void BonedModel::_updateDraw() {

    ////If animation update request was received from an asynchronous event then send vbo to gpu
    //if(_animationUpdateRequest){
    //    //Swap buffer context so the next animation gpu data will be in the gpu when requested
    //    _doubleBufferIndex = !_doubleBufferIndex;

    //    //Load in the next frame of the animation
    //    _animations[_currentAnimation]->loadBonedFrame(this);
    //    _updateLock.lock(); _animationUpdateRequest = false; _updateLock.unlock();
    //}

    Model::_updateDraw();
}

void BonedModel::_updateKeyboard(unsigned char key, int x, int y) {
    //Update animation 

    //Call base class keyboard handling
    Model::_updateKeyboard(key, x, y);
}

void BonedModel::_updateMouse(int button, int state, int x, int y) {
    //Invoke an animation 

    //Call base class keyboard handling
    Model::_updateMouse(button, state, x, y);
}

GLuint BonedModel::getIndexContext(){
    return _indexContext;
}

GLuint BonedModel::getWeightContext(){
    return _weightContext;
}

std::vector<Matrix>* BonedModel::getBones(){

     BoneFrame *frame = getAnimation()->getBoneFrames()[0];
     return frame->getBones();
}
