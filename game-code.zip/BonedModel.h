#pragma once

#include "AnimatedModel.h"
#include <mutex>

class BonedModel : public AnimatedModel {

    GLuint _indexContext;
    GLuint _weightContext;

protected:
    void                    _updateKeyboard(unsigned char key, int x, int y); //Do stuff based on keyboard update
    void                    _updateMouse(int button, int state, int x, int y); //Do stuff based on mouse update
    void                    _updateDraw();

public:
    BonedModel(std::string name, ViewManagerEvents* eventWrapper);
    ~BonedModel();

    GLuint getIndexContext();
    GLuint getWeightContext();
    std::vector<Matrix>* getBones();

};