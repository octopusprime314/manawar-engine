/*
* Matrix is part of the ReBoot distribution (https://github.com/octopusprime314/ReBoot.git).
* Copyright (c) 2017 Peter Morley.
*
* ReBoot is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, version 3.
*
* ReBoot is distributed in the hope that it will be useful, but
* WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
* General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

/**
*  Matrix class. Handles matrix transforms
*/

#pragma once
#include "Vector4.h"
#include <math.h>

const float PI = 3.14159265f;
const float PI_OVER_180 = PI / 180.0f;

class Matrix {


    //OPENGL Matrix layout
    //P is a dimensional position vector in x,y,z
    //X coordinate vector
    //Y coordinate vector
    //Z coordinate vector
    //| Xx Xy Xz Px |  
    //| Yx Yy Yz Py |  
    //| Zx Zy Zz Pz |  
    //| 0  0  0  1  |  

    //To Create a Translation Matrix Change P
    //To Create a Rotation Matrix Change X,Y and Z
    //To Create a Scaling Matrix Change Xx, Yy, Zz

    //Translation Matrix of a +5 change in X position
    //| 1 0 0 5 |  
    //| 0 1 0 0 |  
    //| 0 0 1 0 |  
    //| 0 0 0 1 |  

    //Rotation Matrix of a theta change around X axis
    //| 1  0    0   0 |  
    //| 0 cos -sin  0 |  
    //| 0 sin  cos  0 |  
    //| 0  0    0   1 |  

    //Rotation Matrix of a theta change around Y axis
    //| cos 0  sin  0 |  
    //|  0  1   0   0 |  
    //|-sin 0  cos  0 |  
    //|  0  0   0   1 |  

    //Rotation Matrix of a theta change around Z axis
    //| cos -sin 0  0 |  
    //| sin  cos 0  0 |  
    //|  0    0  1  0 |  
    //|  0    0  0  1 |  

    //Scale Matrix of 2
    //| 2 0 0 0 |  
    //| 0 2 0 0 |  
    //| 0 0 2 0 |  
    //| 0 0 0 1 |  


    float _matrix[16];

public:
    Matrix();
    Matrix(float *mat);
    Matrix(double *mat);

    Matrix        transpose(); //Returns transpose of matrix
    Matrix        inverse(); //Returns inverse of matrix
    Matrix        operator * (Matrix mat);
    Vector4       operator * (Vector4 vec);
    Matrix        operator * (double scale);
    Matrix        operator * (float scale);
    Matrix        operator + (Matrix mat);
    float*        getFlatBuffer();
    void          display();

    static Matrix rotationAroundX(float degrees); //Build rotation matrix around the x axis
    static Matrix rotationAroundY(float degrees); //Build rotation matrix around the y axis
    static Matrix rotationAroundZ(float degrees); //Build rotation matrix around the z axis
    static Matrix translation(float x, float y, float z); //Build translation matrix
    static Matrix scale(float scalar); //Build a scale matrix
    static Matrix scale(float x, float y, float z); //Build a scale matrix

    //Used specific for view transformations associated with a camera view
    static Matrix cameraRotationAroundX(float degrees); //Build rotation matrix around the x axis
    static Matrix cameraRotationAroundY(float degrees); //Build rotation matrix around the y axis
    static Matrix cameraRotationAroundZ(float degrees); //Build rotation matrix around the z axis
    static Matrix cameraTranslation(float x, float y, float z); //Build translation matrix
    static Matrix cameraProjection(float angleOfView, float aspectRatio, float near, float far);
};